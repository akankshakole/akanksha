package com.javatpoint;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;  



@Controller  
public class HelloWorldController {  
      
    @RequestMapping("/hello")  
    public ModelAndView helloWorld(HttpServletRequest request,HttpServletResponse res) throws IOException 
    {  
    	PrintWriter pw=res.getWriter();
    	res.setContentType("text/html");
    	String a =request.getParameter("t1");
    	String b =request.getParameter("t2");
    	String c =request.getParameter("t3");
    	String d =request.getParameter("t4");
    	String e1 =request.getParameter("t5");
    	String f =request.getParameter("t6");
    	String g =request.getParameter("t7");

    	try 
    	{ 
    		Class.forName("oracle.jdbc.driver.OracleDriver");
    		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","1234");
    		 String key=request.getParameter("t8");
    		
    		if(key.equals("insert"))
    	    {
    	    PreparedStatement st=con.prepareStatement("insert into  employee values(?,?,?,?,?,?,?)");
    		
    		st.setString(1,a);
    		st.setString(2,b);
    		st.setString(3,c);
    		st.setString(4,d);
    		st.setString(5,e1);
    		st.setString(6,f);
    		st.setString(7,g);
    		st.execute();
    		
    		String message = "Data inserted "+a;  
            return new ModelAndView("hellopage", "message",message);  
    		
    	    }
    		
    		if(key.equals("update"))
    	    {
    	    PreparedStatement st=con.prepareStatement("update employee set name=?,password=?,salary=?,designation=?,phoneno=?,email=? where empno=?");
    		
    	    
    		st.setString(1,b);
    		st.setString(2,c);
    		st.setString(3,d);
    		st.setString(4,e1);
    		st.setString(5,f);
    		st.setString(6,g);
    		st.setString(7,a);
    		st.execute();
    		
    		String message = "Data updated "+a;  
            return new ModelAndView("hellopage", "message",message);  
    		
    	    }
    		
    		if(key.equals("delete"))
    	    {
    	    PreparedStatement st=con.prepareStatement("delete from  employee where Empno=?");
    		
    		st.setString(1,a);
    		
    		st.execute();
    		
    		String message = "Data deleted "+a;  
            return new ModelAndView("hellopage", "message",message);  
    		
    	    }
    		
    		if(key.equals("select"))
    	    {
    	  PreparedStatement st=con.prepareStatement("select * from employee");
    	  ResultSet rs=st.executeQuery();
    	  while(rs.next()){
    		  
    		  System.out.println(rs.getString(1)+""+rs.getString(2)+""+rs.getString(3)+""+rs.getString(4)+""+rs.getString(5)+""+rs.getString(6)+""+rs.getString(7));    		  
    	  }
    	
    		
    		
    		
    		String message = "Data "+a+b;  
            return new ModelAndView("hellopage", "message",message);  
    		
    	    }
    		
    	 
         
        
    }catch(Exception e) 
    	{
    	e.printStackTrace();
    	}
    
    	String message = "submitted "+a;  
        return new ModelAndView("hellopage", "message",message); 	
        
}
}