package com.dineshonjava.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

 
@Entity
@Table(name="Employee")
public class Employee implements Serializable{

	 
	
	@Id
	 
	@Column(name = "empid")
	private Integer empId;
	
	@Column(name="empname")
	private String empName;
	
	@Column(name="empbankname")
	private String empBankname;
	
	@Column(name="empaddress")
	private String empAddress;
	
	@Column(name="amount")
	private Integer amount;
	
	@Column(name="phone")
	private Long phone;
	
	@Column(name="email")
	private String email;
	
	

	public String getEmpBankname() {
		return empBankname;
	}

	public void setEmpBankname(String empBankname) {
		this.empBankname = empBankname;
	}

	public Integer getAmount() {
		return amount;
	}

	public void setAmount(Integer amount) {
		this.amount = amount;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpAddress() {
		return empAddress;
	}

	public void setEmpAddress(String empAddress) {
		this.empAddress = empAddress;
	}

	
	
	public Long getPhone() {
		return phone;
	}

	public void setPhone(Long phone) {
		this.phone = phone;
	}
	
	

}
