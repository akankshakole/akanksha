import java.util.*;

import org.hibernate.*;
import org.hibernate.cfg.*;

public class PART1 {
	public static void main(String args[]) throws Exception {
		Configuration cfg=new Configuration();
		SessionFactory sf=cfg.configure().buildSessionFactory();
		Session ss = sf.openSession();

		MYPOJO2 pj = new MYPOJO2(); // object of mypojo class 
		String empno, name, phoneno, address;
		Scanner sc = new Scanner(System.in);

		

		while (true) {
			System.out.println("Select 1 to Insert");
			System.out.println("Select 2 to Delete");
			System.out.println("Select 3 to Update");
			System.out.println("Select 4 to Display");
			System.out.println("Select 5 to Exit");
			int x = sc.nextInt();
			switch (x) {
			case 1:
				Transaction tx = ss.beginTransaction();
				Query q = ss.createQuery("from MYPOJO2"); // query select from mypojo class(table)

				System.out.println("INSERTING VALUES");
				System.out.println("Enter empno");
				empno = sc.next();
				pj.setEmpno(empno);
				System.out.println("Enter name");
				name = sc.next();
				pj.setName(name);
				System.out.println("Enter phoneno");
				phoneno = sc.next();
				pj.setPhoneno(phoneno);
				System.out.println("Enter address");
				address = sc.next();
				pj.setAddress(address);
				ss.save(pj);

				q.setFirstResult(0);
				q.setMaxResults(10);
				List list = q.list();// will return the records from 0 to 10th number
				System.out.println(list);
				tx.commit();
				break;
			case 2:
				Transaction tx1 = ss.beginTransaction();
				System.out.println("Deleting data");
				System.out.println("Enter empoyee id for deleteing ");
				empno = sc.next();
				Query q3 = ss.createQuery("delete from MYPOJO2 where empno=:x");
				q3.setParameter("x", empno);
				q3.executeUpdate();
				System.out.println(" row Deleted");
				tx1.commit();
				break;
			case 3:
				Transaction tx2 = ss.beginTransaction();
				System.out.println("Updating row ");
				System.out.println("Enter emp no for update");
				empno = sc.next();
				System.out.println("Enter name");
				name = sc.next();
				System.out.println("Enter phone no");
				phoneno = sc.next();
				System.out.println("Enter address");
				address = sc.next();

				Query q4 = ss.createQuery("update MYPOJO2 set name=:n, phoneno=:p, address=:ad where empno=:e");
				q4.setParameter("n", name);
				q4.setParameter("p", phoneno);
				q4.setParameter("ad", address);
				q4.setParameter("e", empno);

				int status1 = q4.executeUpdate();
				System.out.println(empno + "row updated " + status1);
				tx2.commit();
				break;
			case 4:

				Query q5 = ss.createQuery("from MYPOJO2");
				q5.setFirstResult(0);
				q5.setMaxResults(10);
				List stud1 = q5.list();
				System.out.println(stud1);
				Iterator it1 = stud1.iterator();
				while (it1.hasNext()) {
					pj = (MYPOJO2) it1.next();
					System.out.println("Display Last Entry");
					System.out.println(pj.getEmpno());
					System.out.println(pj.getName());
					System.out.println(pj.getPhoneno());
					System.out.println(pj.getAddress());
				}
				break;
			case 5:
				System.exit(x);
				break;

			}

		}
	}
}
/*
 * create table details1(phoneno varchar2(30),email varchar2(30),password
 * varchar2(30));
 * 
 * insert into details1 values('99887766','sandip@gmail.com','1234')
 * 
 * create table details(rollno varchar2(30),name varchar2(30),address
 * varchar2(30));
 * 
 * insert into details values('101','sandip','bangalore')
 */